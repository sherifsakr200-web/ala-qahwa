import 'dart:async';
import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Ads initialization is best-effort. The scorekeeper remains usable offline.
  try {
    await MobileAds.instance.initialize();
  } catch (_) {}
  runApp(const AlaQahwaApp());
}

const coffee = Color(0xFF17110D);
const panel = Color(0xFF2A1D16);
const gold = Color(0xFFFFC857);
const red = Color(0xFFE34C55);
const blue = Color(0xFF3D9BE9);

class AlaQahwaApp extends StatelessWidget {
  const AlaQahwaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'عَ القهوة',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: coffee,
        colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const ScoreHome(),
    );
  }
}

class ScoreHome extends StatefulWidget {
  const ScoreHome({super.key});

  @override
  State<ScoreHome> createState() => _ScoreHomeState();
}

class _ScoreHomeState extends State<ScoreHome> {
  String teamA = 'فريق الصقور';
  String teamB = 'فريق الأصدقاء';
  int scoreA = 0;
  int scoreB = 0;
  int target = 101;
  final List<String> history = [];
  final ConfettiController confetti = ConfettiController(duration: const Duration(seconds: 4));
  bool winnerShown = false;
  BannerAd? banner;
  bool bannerReady = false;

  @override
  void initState() {
    super.initState();
    _load();
    _loadBanner();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      teamA = p.getString('teamA') ?? teamA;
      teamB = p.getString('teamB') ?? teamB;
      scoreA = p.getInt('scoreA') ?? 0;
      scoreB = p.getInt('scoreB') ?? 0;
      target = p.getInt('target') ?? 101;
      history.addAll(p.getStringList('history') ?? []);
    });
    _checkWinner();
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('teamA', teamA);
    await p.setString('teamB', teamB);
    await p.setInt('scoreA', scoreA);
    await p.setInt('scoreB', scoreB);
    await p.setInt('target', target);
    await p.setStringList('history', history);
  }

  void _loadBanner() {
    // Google's official test banner ID. Replace with your own AdMob unit ID before release.
    final ad = BannerAd(
      adUnitId: 'ca-app-pub-3940256099942544/6300978111',
      request: const AdRequest(),
      size: AdSize.banner,
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          if (!mounted) { ad.dispose(); return; }
          setState(() { banner = ad as BannerAd; bannerReady = true; });
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          // No banner is shown if offline or no ad is available.
        },
      ),
    );
    ad.load();
  }

  @override
  void dispose() {
    banner?.dispose();
    confetti.dispose();
    super.dispose();
  }

  Future<void> _editTeam(bool isA) async {
    final controller = TextEditingController(text: isA ? teamA : teamB);
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: panel,
        title: Text(isA ? 'اسم الفريق الأول' : 'اسم الفريق الثاني'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 24,
          textDirection: TextDirection.rtl,
          decoration: const InputDecoration(hintText: 'اكتب اسم الفريق'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('حفظ')),
        ],
      ),
    );
    if (result != null && result.trim().isNotEmpty) {
      setState(() { if (isA) { teamA = result.trim(); } else { teamB = result.trim(); } });
      await _save();
    }
  }

  Future<void> _setTarget() async {
    final c = TextEditingController(text: '$target');
    final result = await showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: panel,
        title: const Text('نقاط الفوز'),
        content: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(hintText: 'مثال: 101 أو 301'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              final n = int.tryParse(c.text.trim());
              if (n != null && n > 0) Navigator.pop(context, n);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    if (result != null) {
      setState(() { target = result; winnerShown = false; });
      await _save();
      _checkWinner();
    }
  }

  Future<int?> _askPoints({required bool adding}) async {
    final c = TextEditingController();
    return showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: panel,
        title: Text(adding ? 'إضافة نقاط' : 'خصم نقاط'),
        content: TextField(
          controller: c,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(hintText: 'اكتب أي عدد من النقاط'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              final n = int.tryParse(c.text.trim());
              if (n != null && n >= 0) Navigator.pop(context, n);
            },
            child: const Text('تأكيد'),
          ),
        ],
      ),
    );
  }

  Future<void> _changeScore(bool isA, bool adding) async {
    final n = await _askPoints(adding: adding);
    if (n == null) return;
    setState(() {
      if (isA) {
        scoreA = adding ? scoreA + n : (scoreA - n).clamp(0, 1 << 30);
      } else {
        scoreB = adding ? scoreB + n : (scoreB - n).clamp(0, 1 << 30);
      }
      winnerShown = false;
    });
    await _save();
    _checkWinner();
  }

  void _checkWinner() {
    if (winnerShown) return;
    String? winner;
    if (scoreA >= target && scoreA > scoreB) winner = teamA;
    if (scoreB >= target && scoreB > scoreA) winner = teamB;
    if (winner != null && mounted) {
      winnerShown = true;
      history.insert(0, '$winner فاز — $scoreA : $scoreB');
      if (history.length > 50) history.removeLast();
      _save();
      confetti.play();
      Future.delayed(const Duration(milliseconds: 350), () {
        if (mounted) _showWinner(winner!);
      });
    }
  }

  void _showWinner(String winner) {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) => Stack(
        alignment: Alignment.topCenter,
        children: [
          AlertDialog(
            backgroundColor: panel,
            title: const Text('🏆 مبروك الفوز!', textAlign: TextAlign.center),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.emoji_events, color: gold, size: 76),
                const SizedBox(height: 12),
                Text(winner, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: gold), textAlign: TextAlign.center),
                const SizedBox(height: 8),
                Text('$scoreA  —  $scoreB', style: const TextStyle(fontSize: 22)),
                const SizedBox(height: 8),
                const Text('قعدة حلوة وفوز مستحق ☕', textAlign: TextAlign.center),
              ],
            ),
            actions: [
              FilledButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('تمام'),
              ),
            ],
          ),
          IgnorePointer(child: ConfettiWidget(
            confettiController: confetti,
            blastDirectionality: BlastDirectionality.explosive,
            shouldLoop: false,
            numberOfParticles: 18,
            gravity: 0.18,
          )),
        ],
      ),
    );
  }

  Future<void> _newGame() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: panel,
        title: const Text('مباراة جديدة؟'),
        content: const Text('هيتم تصفير النقاط الحالية مع الاحتفاظ بسجل المباريات.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ابدأ')),
        ],
      ),
    );
    if (ok == true) {
      setState(() { scoreA = 0; scoreB = 0; winnerShown = false; });
      await _save();
    }
  }

  void _showHistory() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: panel,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: 360,
          child: Column(
            children: [
              const Text('سجل المباريات', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Expanded(
                child: history.isEmpty
                    ? const Center(child: Text('لسه مفيش مباريات مسجلة'))
                    : ListView.builder(
                        itemCount: history.length,
                        itemBuilder: (context, i) => ListTile(
                          leading: const Icon(Icons.emoji_events, color: gold),
                          title: Text(history[i], textDirection: TextDirection.rtl),
                        ),
                      ),
              ),
              TextButton(
                onPressed: () async {
                  setState(() => history.clear());
                  await _save();
                  if (context.mounted) Navigator.pop(context);
                },
                child: const Text('مسح السجل'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _teamCard({required bool isA}) {
    final name = isA ? teamA : teamB;
    final score = isA ? scoreA : scoreB;
    final color = isA ? red : blue;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: panel,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: color.withOpacity(.7), width: 1.5),
          boxShadow: [BoxShadow(color: color.withOpacity(.12), blurRadius: 18)],
        ),
        child: Column(
          children: [
            InkWell(
              onTap: () => _editTeam(isA),
              borderRadius: BorderRadius.circular(12),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 2),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Flexible(child: Text(name, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
                      style: TextStyle(color: color, fontSize: 17, fontWeight: FontWeight.bold))),
                    const SizedBox(width: 4),
                    const Icon(Icons.edit, size: 15, color: Colors.white54),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text('$score', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: color)),
            Text('من $target نقطة', style: const TextStyle(color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(child: FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 12)),
                  onPressed: () => _changeScore(isA, true),
                  child: const Icon(Icons.add, size: 24),
                )),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton(
                  style: OutlinedButton.styleFrom(foregroundColor: Colors.white70, padding: const EdgeInsets.symmetric(vertical: 12)),
                  onPressed: () => _changeScore(isA, false),
                  child: const Icon(Icons.remove, size: 24),
                )),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              Positioned.fill(
                child: DecoratedBox(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Color(0xFF342116), coffee, Color(0xFF0D0A08)]),
                  ),
                ),
              ),
              Column(
                children: [
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(Icons.coffee, color: gold, size: 28),
                            SizedBox(width: 8),
                            Text('عَ القهوة', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: gold)),
                          ],
                        ),
                        const SizedBox(height: 4),
                        const Text('عداد الدومينو • القعدة الحلوة تبدأ هنا', textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white60, fontSize: 13)),
                        const SizedBox(height: 22),
                        Container(
                          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                          decoration: BoxDecoration(
                            color: Colors.black26, borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: gold.withOpacity(.25)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('🎯 هدف المباراة', style: TextStyle(fontWeight: FontWeight.bold)),
                              Text('$target نقطة', style: const TextStyle(color: gold, fontSize: 18, fontWeight: FontWeight.bold)),
                              IconButton(onPressed: _setTarget, icon: const Icon(Icons.tune, color: gold), tooltip: 'تغيير الهدف'),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            _teamCard(isA: true),
                            const SizedBox(width: 12),
                            _teamCard(isA: false),
                          ],
                        ),
                        const SizedBox(height: 18),
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(color: panel.withOpacity(.75), borderRadius: BorderRadius.circular(18)),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.casino_outlined, color: gold),
                              SizedBox(width: 8),
                              Flexible(child: Text('اكتب عدد النقاط اللي عاوزه — مش لازم تكون 10', textAlign: TextAlign.center,
                                style: TextStyle(color: Colors.white70))),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(child: OutlinedButton.icon(
                              onPressed: _showHistory,
                              icon: const Icon(Icons.history),
                              label: const Text('سجل المباريات'),
                            )),
                            const SizedBox(width: 10),
                            Expanded(child: FilledButton.icon(
                              style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: coffee),
                              onPressed: _newGame,
                              icon: const Icon(Icons.restart_alt),
                              label: const Text('مباراة جديدة'),
                            )),
                          ],
                        ),
                      ],
                    ),
                  ),
                  if (bannerReady && banner != null)
                    SizedBox(
                      width: banner!.size.width.toDouble(),
                      height: banner!.size.height.toDouble(),
                      child: AdWidget(ad: banner!),
                    )
                  else
                    const SizedBox(height: 8),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
